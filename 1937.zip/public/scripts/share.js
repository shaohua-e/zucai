var str = ''
